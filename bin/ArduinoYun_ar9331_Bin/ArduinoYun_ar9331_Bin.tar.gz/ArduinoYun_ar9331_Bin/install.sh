#!/bin/bash
chmod 777 wilddog_*
cp wilddog_daemon wilddog_transfer /usr/bin/
