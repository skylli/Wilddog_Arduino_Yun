#!/bin/bash 
rm /usr/bin/wilddog_daemon /usr/bin/wilddog_transfer